import org.junit.Assert;
import org.junit.Test;
import static org.example.Sum.sumTest;
public class Tests {
    @Test
    public void test(){
        int sum = sumTest(2,2);
        int sumChecked = 4;
        Assert.assertEquals(sum,sumChecked);
    }

}
