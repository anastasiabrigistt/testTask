package org.example;

public class Sum {
    public Sum(){

    }
    public static int sumTest(int x, int y){
        return x+y;
    }
}
